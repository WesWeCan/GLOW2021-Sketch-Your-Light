# LICENSE

As the external `sadam.lzo` is using the LZO Library, version 2.10 (March 01, 2017, Copyright &copy; 1996&mdash;2017 Markus F. X. J. Oberhumer), which is licensed under GPLv2, this external is released under GPLv2. You will find a copy of this license in the folder containing the source code of the external as well as attached to the copy of the LZO library.

All other externals are licensed under the Creative Commons Attribution 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by/3.0/ or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.

The `sadam` Library comes free but without any kind of official support or warranty and the author has no responsability for any damage, failure or any other kind of inconvenience that might result from the use of this Library. By using The `sadam` Library you automatically agree to the terms above.
